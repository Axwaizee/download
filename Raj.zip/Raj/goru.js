const num1 = 5;
const num2 = 3;
//add two numbers 
const sum = num1 + num2;
// display the sum
console.log('The sum of'  +  num1 + 'and' + num2 + 'is:' + sum);