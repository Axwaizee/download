#include<stdio.h>
int main()
{
    float num1,num2;
    num1=32.45;
    num2=89.56;
    printf("my number is:%f and %f",num1,num2);
}
