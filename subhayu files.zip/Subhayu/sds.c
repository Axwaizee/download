#include<stdio.h>
int main()
{
int roll;
roll=20;
printf("my roll no. : %d",roll);
}
