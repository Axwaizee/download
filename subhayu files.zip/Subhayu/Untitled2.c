#include<stdio.h>
int main()
{
printf("welcome to bca1");
}
