#include<stdio.h>
int main()
{
float roll;
roll= 20.99;
printf("my roll no. : %f",roll);
}
