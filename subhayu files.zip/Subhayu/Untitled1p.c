#include<stdio.h>
main()
{
int number;
float amount;
number = 100;
amount = 41.7 + 22.8 ;
printf("%d\n",number);
printf("%64.5f",amount);
}
