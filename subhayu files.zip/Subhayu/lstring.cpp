#include<iostream>
#include<cstring>
using namespace std;
int main()
{
    char a[10]="hello";
    cout<<strlen(a)<<endl;
    char b[10]="Anup";
    cout<<strlen(b)<<endl;

}
