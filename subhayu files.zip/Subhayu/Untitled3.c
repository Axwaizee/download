#include<stdio.h>
int main()
{
    int num1,num2;
    num1=23;
    num2=9;
    printf("your numbers are:%d and %d",num1,num2);
}
