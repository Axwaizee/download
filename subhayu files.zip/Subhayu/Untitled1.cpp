#include<iostream>
using namespace std;
struct im
{
    int id;
    char a[20];
};
int main(){
     im details={1,"akum"};
     cout<<details.id<<endl;
     cout<<details.a;
}
